CYBERSECURITY PORTFOLIO STARTER

1. Extract this folder.
2. Open index.html in your browser, or serve the folder using a local web server.
3. Edit index.html to update text, social links and project details.
4. Replace assets/Resume.pdf with your own CV.
5. Replace assets/profile-photo.jpg if you want a different profile photo.
6. Replace assets/cyber-background.png to change the hero background.

IMPORTANT EDITS BEFORE PUBLISHING:
- Replace your.email@example.com with your real email address.
- Confirm LinkedIn and GitHub links.
- Add your latest CV as assets/Resume.pdf.
- Update course/certification status to show completed vs in progress accurately.
- Check the internship dates and wording.

This is a front-end starter. It does not alter or connect to an existing Flask/MySQL database.
